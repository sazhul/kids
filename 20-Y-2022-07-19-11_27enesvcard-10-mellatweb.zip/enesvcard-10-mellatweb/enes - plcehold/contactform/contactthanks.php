<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Strict//EN">

<head>
	
	<link rel="stylesheet" type="text/css" href="style.css" />
</head>

<body class="contact-body">

	<div id="page-wrap">

		<br /><br />
		
			
		<h1>Your message has been sent!</h1><br />
		
		<p><a href="index.html#contact">Back to Contact Form</a></p>
	
	</div>
	


</body>

</html>